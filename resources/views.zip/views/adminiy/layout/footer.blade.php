<footer class="footer hidden-xs-down">
<p>© Adminiy {{$v}}. All rights reserved.</p>
</footer>