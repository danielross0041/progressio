@extends('layouts.main')
@section('content')
<section class="messages_das_sec con_sec_chg">
    <div class="container">
        <div class="row">
            @include('customer.sidebar')
            <div class="col-md-9 pt-5 pb-5">
                <div class="dashborad_main_sec">
                    <div class="dash_head_sec">
                        <h2>Under Development</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection
@section('css')
<style type="text/css">

</style>
@endsection
@section('js')
<script type="text/javascript">
    (() => {
        /*in page css here*/
    })()
</script>
@endsection