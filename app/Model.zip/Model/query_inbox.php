<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class query_inbox extends Model
{
    protected $table='query_inbox';
}
