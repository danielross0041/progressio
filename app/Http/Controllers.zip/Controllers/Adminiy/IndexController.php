<?php
namespace App\Http\Controllers\Adminiy;
use App\Http\Controllers\Controller;
use Auth;
use View;
use File;
use DB;
use Schema;
use Storage;
use App\Model\ytables;
use App\Model\imagetable;
use App\Model\tutor_meeting_admin;
use App\Model\tutor_quiz_questions;
use App\Model\tutor_quiz_answers;
use App\Model\bookings;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Validator;
use Artisan;
use Helper;
class IndexController extends Controller
{
    public function __construct()
    {
        $favicon=Helper::OneColData('imagetable','img_path',"table_name='favicon' and ref_id=0 and is_active_img='1'");
        View()->share('v',config('app.vadminiy'));
        View()->share('favicon',$favicon);
    }
    public function panel()
    {
    	// dd("here");
    	$booking = bookings::where('status','!=',1)->get();
    	$total = 0;
    	foreach ($booking as $key => $value) {
    		$total +=$value->total;
    	}
    	// dd($total);
        $recentSignups = Helper::fireQuery("SELECT left(name,1) as _fc,users.*,imagetable.img_path from users left join imagetable on imagetable.table_name='users' and imagetable.type='1' and imagetable.ref_id = users.id order by users.id desc ".Helper::getPaginator(20));
        return view('adminiy.panel')->with(compact('recentSignups','total'));
    }
    public function sendmail()
    {
        return view('adminiy.fullwidgets.sendmail')->with('title','Send Email');
    }
	public function tutor_meeting_admin(){
		$tutor_meeting_admin = tutor_meeting_admin::orderBy('id','desc')->paginate(20);
		return view('adminiy.tutor_meeting_admin')->with('title','Tutor Meetings')
		->with('adminiy_tutor_meeting_admin',true)
		->with('tutor_meeting_admin',$tutor_meeting_admin);
	}
	public function tutor_meeting_admin_status($id,$status){
		$tutor_meeting_admin=tutor_meeting_admin::findOrfail($id);
		$tutor_meeting_admin->meeting_success=$status;
		$tutor_meeting_admin->save();
		return back()->with('notify_success','Meeting '.($status==1?'accepted':'rejected').', Notification sent');
	}
	public function tutor_meeting_admin_sendlink($id){
		$tutor_meeting_admin=tutor_meeting_admin::findOrfail($id);
		return redirect()->route('tutor.safeguardingvideo',[$tutor_meeting_admin->tutor_id]);
	}
	public function add_answers($id){
		$tutor_quiz_questions=tutor_quiz_questions::findOrfail($id);
		return view('adminiy.tutor_quiz_questions_answers')->with('title','Add Answers')
		->with('tutor_quiz_questions_ytmenu',true)
		->with('tutor_quiz_questions',$tutor_quiz_questions);
	}
	public function saveanswers(Request $request,$id){
		tutor_quiz_answers::where('question_id',$id)->delete();
		foreach($request->values as $value){
			$tutor_quiz_answers = new tutor_quiz_answers;
			$tutor_quiz_answers->question_id=$id;
			$tutor_quiz_answers->option_value=$value['option'];
			$tutor_quiz_answers->is_correct=$value['is_correct'];
			$tutor_quiz_answers->save();
		}
		$this->echoSuccess("saved");
	}
}
