@extends('layouts.main')
@section('content')
<section class="tutor_application_form">
<div class="container">
	<div class="row">
		<div class="tutor_application_head">
			<div class="row">
				<div class="col-md-12">
					<div class="tutor_head_sec">
						<h2>Congratulations you have completed the Quiz, and got <b>{{$percent}}%</b>, Your profile will be live in an hour</h2>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</section>
@endsection
@section('css')
<style type="text/css">
    /*in page css here*/
</style>
@endsection
@section('js')
<script type="text/javascript">

</script>
@endsection