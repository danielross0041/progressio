<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class tutor_schedule extends Model
{
    protected $table='tutor_schedule';
}
